﻿namespace CarShop.DomainModel.Entities; 

public class MarkedCar: ABaseEntity {

   #region properties
   public override Guid Id { get; set; } = Guid.Empty;
   
   // Many-to-Many         MarkedCar ---> User [1]     
   //               [0..*] MarkedCar <-- User    
   public User User   { get; set; } = NullUser.Instance;
   public Guid UserId { get; set; } = Guid.Empty;
   //                      MarkedCar ---> Car [1]
   //               [0..*] MarkedCar <--- Car    
   public Car Car    { get; set; } = NullCar.Instance;
   public Guid CarId { get; set; } = Guid.Empty;
   #endregion
   
   #region ctor
   public MarkedCar() { }
   #endregion
   
   #region methods
   public MarkedCar Set(Guid id, User user, Car car) { 
      Id = (id == Guid.Empty) ? Guid.NewGuid() : id; 

      // MarkedCar --> User [1]
      User = user;
      UserId = user.Id;
      // User --> MarkedCar [0..*]
      user.MarkedCars.Add(this);

      // MarkedCar --> Car [1]
      Car = car;
      CarId = car.Id;
      // Car --> MarkedCar [0..*]
      car.MarkedCars.Add(this);

      return this;
   }
   
   public string AsString() =>
      $"{Id.ToString()[0..8]} User {User.LastName} {UserId.ToString()[0..8]} " +
      $"Car {Car.Make} {Car.Model} {CarId.ToString()[0..8]}";
   #endregion
}