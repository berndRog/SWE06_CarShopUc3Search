﻿using CarShop.DomainModel.Enums;
using CarShop.Utilities;
namespace CarShop.DomainModel.Entities;

public class User: ABaseEntity {
   #region properties
   public override Guid Id{ get; set; } = Guid.Empty;
   public string FirstName{ get; set; } = string.Empty;
   public string LastName{ get; set; } = string.Empty;
   public string Email{ get; set; } = string.Empty;
   public string Phone{ get; set; } = string.Empty;
   public string? ImagePath{ get; set; } = null;
   public string UserName{ get; set; } = string.Empty;
   public string Password{ get; set; } = string.Empty;
   public string Salt{ get; set; } = string.Empty;
   public Role Role{ get; set; } = Role.User;
   // User --> Address [0..1]
   public Address? Address { get; set; } = null;
   // Navigation-Property User --> Cars [0..*]  
   public IList<Car> OfferedCars { get; set; } = new List<Car>();
   // Navigation-Property User --> MarkedCars [0..*] 
   public IList<MarkedCar> MarkedCars { get; set; } = new List<MarkedCar>();
   #endregion

   #region ctor
   public User(): base() {  Id = Guid.NewGuid();}
   #endregion

   #region methods
   public User Set(Guid id, string firstName, string lastName, 
      string email, string phone, string? imagePath,
      string username, string password, string salt, Role role) {
      Id = (id == Guid.Empty) ? Guid.NewGuid() : id;
      FirstName = firstName;
      LastName = lastName;
      Email = email;
      Phone = phone;
      ImagePath = imagePath;
      UserName = username;
      Password = password;
      Salt = salt;
      Role = role;
      return this;
   }
   public string AsString() {
      string role = Role switch {
         Role.User => "User",
         Role.Customer => "Customer",
         Role.Seller => "Seller",
         _ => "Unknown"
      };
      string s = $"{Id.ToString()[..8]} {FirstName} {LastName} {Email} {Phone} {ImagePath} " +
         $"{UserName} {role}";
      
      if(Address != null) s += Address.AsString();      
      return s;
   }
   
   public string? OfferedCarsAsString() {
      string? s = null;
      if(OfferedCars.Count > 0)      {
         s += "\n OfferedCars {";
         foreach (var car in OfferedCars) 
            s += $"{car.Id.ToString()[..9]} {car.Make} {car.Model}";
         s += "\n }";
      }
      return s;
   }

   public string? MarkedCarsAsString() {
      string? s = null;
      if(MarkedCars.Count > 0)      {
         s += "\n   MarkedCars";
         foreach (var markedCar in MarkedCars) 
            s += $"   {markedCar.Id.ToString()[..9]} {markedCar.Car.Make} {markedCar.Car.Model}\n";
      }
      return s;
   }
   #endregion

   #region methods Address
   public void AddOrUpdateAddress(string street, string number, string zip, string city) {
      if (Address == null) {
         Address = new Address().Set(Guid.NewGuid(), street, number, zip, city);
         Address.UserId = Id;
      }
      else {
         Address.Street = street;
         Address.Number = number;
         Address.Zip = zip;
         Address.City = city;
      }
   }

   public void AddOrUpdateAddress(Address address) {
      Address = address;
      Address.UserId = Id;
   }

   public void RemoveAddress() {
      if(Address == null) return;
      Address.UserId = Guid.Empty;
      Address = null;
      
   }
   #endregion

   #region methods OfferedCars
   public Car? FindCarById(Guid carId) =>
      OfferedCars.FirstOrDefault(car => car.Id == carId);
   
   public IList<Car> GetAllCars() =>
      OfferedCars.ToList();   

   public void AddCar(Car car) {
      car.UserId = Id;
      car.User = this;
      OfferedCars.Add(car);
   }

   public void UpdateCar(Guid carId, double price) {
      Car? foundCar = OfferedCars.FirstOrDefault(c => c.Id == carId);
      if (foundCar == null)
         throw new Exception($"UpdateOfferedCars(): Car with id {Utils.Guid8(carId)} not found");
      foundCar.Price = price;
   }

   public void RemoveCar(Car car) =>
      OfferedCars.Remove(car);
   #endregion

   #region method MarkedCars
   public void AddCarToMarkedCarsList(Car car) =>
      new MarkedCar().Set(Guid.NewGuid(), this, car);

   public Car? FindMarkedCarByCarId(Guid carId) {
      MarkedCar? markedCar = MarkedCars.FirstOrDefault(markedCar => 
         markedCar?.UserId == Id && markedCar?.CarId == carId);
      return markedCar?.Car;
   }
      
   public void AddMarkedCar(MarkedCar markedCar) =>
      MarkedCars.Add(markedCar);
   
   public void DeleteMarkedCar(MarkedCar markedCar) =>
      MarkedCars.Remove(markedCar);      
   #endregion
}